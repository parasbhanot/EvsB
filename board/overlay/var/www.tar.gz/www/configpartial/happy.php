
<DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	 
</head>
<body>
<div class="jumbotron text-xs-center">
  <h3 class="display-5" style="text-align: center;">Database Updated Successfully!</h3>
  <img src="images/smile.jpg"  style="width: 120px; height: 120px; display: block;margin-left: auto;margin-right: auto;">
  <p class="lead" style="text-align: center;"><strong>For Further Changes</strong> Go to home page.</p>
  <hr>
  
  <p class="lead">
  	<form action="../dashboard/bootback.php">
 <button type="submit" class="btn btn-primary btn-sm" style="margin: auto;display: block;"  ><span class="glyphicon glyphicon-circle-arrow-left"></span>  Back to homepage</button>
</form> 
  </p>
</div>

</body>
</html>
