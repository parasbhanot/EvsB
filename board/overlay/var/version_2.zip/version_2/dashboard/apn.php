<?php
          $file = fopen("/etc/ppp/peers/quectel-chat-connect", "r");
           $members = array();
          

           while (!feof($file)) {
          $members[] = fgets($file);
            }

          fclose($file);

          //var_dump($members);
          //echo $members[11];]
          $IP=array();
          $IP=(( explode( ',', $members[11] ) ));
          $APN=trim($IP[2], '"');
         
          
          
          if ($_SERVER['REQUEST_METHOD'] === 'POST')
          {
            if (isset($_POST['submit_APN']))

            { 
              
              $filew = fopen("/etc/ppp/peers/quectel-chat-connect", "r+");
              //$members1=array();

              if(empty($APN)){
              $members=str_replace('OK AT+CGDCONT=1,"IP","",,0,0','OK AT+CGDCONT=1,"IP","'.$_POST['APN'].'",,0,0',$members);
              
              
            } else{
              $members=(str_replace($APN,$_POST['APN'],$members));
              //print_r($members);
            } 

              
            

              //$members1=(str_replace($APN,$_POST['APN'],$members,$i));
              //print_r() $members1;
              $str=implode(' ',$members);
              
              fwrite($filew,$str);
              fclose($filew);
              echo '<script type="text/javascript">';  
              echo 'window.location.href = "happy.php";';
              echo '</script>';

             
              
            }
          }
          ?>