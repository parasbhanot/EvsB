
<DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	 
</head>
<style>
body{background-color: #ebeeef; margin-left: 350px;}
.rcorner {
  border-radius: 30px;
  border: 2px solid #fff; background-color: #fff;
  padding: 20px; margin-top: 20px;
  width: 600px;
  height: 450px; 
  </style> 
<body>
	<div class="rcorner">
<div class="jumbotron text-xs-center" style="background-color: #fff;">
  <h3 class="display-5" style="text-align: center;">APN set successfully!</h3>
  <br>
  <img src="images/happy.png" style="height: 140px; width: 140px; margin-left: 200px;">
  <p class="lead" style="text-align: center;"><strong>For Further Changes</strong> Go to home page.</p>
  <hr>
  
  <p class="lead">
  	<form action="../dashboard/dashboard.php">
 <button type="submit" class="btn btn-primary btn-sm" style="margin: auto;display: block;"  ><span class="glyphicon glyphicon-circle-arrow-left"></span>  Back to homepage</button>
</form> 
  </p>
</div>
</div>
</body>
</html>
